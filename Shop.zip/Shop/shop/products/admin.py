from django.contrib import admin
from .models import Products ,Offers


class ProductsAdmin(admin.ModelAdmin):
    list_display=('name','price','Stock')


class OffersAdmin(admin.ModelAdmin):
    list_display=('code','description','discount')
    
# Register your models here.
admin.site.register(Products,ProductsAdmin)
admin.site.register(Offers,OffersAdmin)

